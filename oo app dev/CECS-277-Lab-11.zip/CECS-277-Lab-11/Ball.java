import java.util.*;
public class Ball
{
  //initialize instance variables and HashMap
  private static HashMap<String, Ball> colors = null;
  private String color; 
  private int bounces; 
  private int rolls; 

  /**
  * @param c takes String objects
  * constructor method to initailze color 
  */
  private Ball(String c)
  {
    color = c;
  }
  
  /**
  * @param c takes String objects
  * return the color of the ball 
  * check if the color of the ball is in the map, if so, return it, otherwise construct it and return it
  */
  public static Ball getInstance(String c)
  {
    Ball val = new Ball(c);
    if(colors == null)
    {
      colors = new HashMap<String, Ball>();
      colors.put(c,val);
      return colors.get(c);
    }  
    else
    {
      if (colors.containsKey(c))
      {
        return colors.get(c);
      }
      else
      {
        colors.put(c,val);
        return colors.get(c);
      }
    }  
  }

  /**
  * counts the number of times the user chooses to bounce the ball
  */
  public void bounce()
  {
     if(colors.containsKey(color))
     {
      bounces += 1;
     }

  }

  /**
  * counts the number of times the user chooses to roll the ball
  */
  public void roll()
  {
     if(colors.containsKey(color))
     {
       rolls += 1;
     }

  }

  /**
  * return the String value of the ball
  * display the stats of the ball
  */
  @Override
  public String toString()
  {
    return "\n" + color + " Ball: " + "\n--------\nRolls: " + rolls + "\nBounces: " + bounces;
    
  }

}