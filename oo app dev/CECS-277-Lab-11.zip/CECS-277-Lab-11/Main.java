/**
* Name: Ivy Ly and Ayush Patel
* Date: 11/8/2021
* Description: Allow the user to choose the color of the ball, and to bounce or roll the ball.
*/
import java.util.*;
import java.io.*;
class Main {
  public static void main(String[] args) 
  {
    String input = "";
    int num = 0;
    
    System.out.println("Choose a ball color(q to quit)");
    input = CheckInput.getString();
    while(!input.equals("q"))
    {
      System.out.println("1. Roll ball");
      System.out.println("2. Bounce ball");
      num = CheckInput.getIntRange(1,2);
      
      Ball colorBall = Ball.getInstance(input);
      
      if(num == 1)
      {
        System.out.println("\nYou rolled the "+ input + " ball.");
        colorBall.roll();
      }
      else
      {
        System.out.println("\nYou bounced the "+ input + " ball.");
        colorBall.bounce();
      }

      System.out.println(Ball.getInstance(input));
      System.out.println("\nChoose a ball color(q to quit)");
      input = CheckInput.getString();
      
    }
  }
}