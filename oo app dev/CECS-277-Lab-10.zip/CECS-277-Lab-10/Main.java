/**
* Name: Ivy Ly and Ayush Patel
* Date: 11/1/2021
* Description: A program that keeps track of the frequency of each word in the text file by using a TreeMap. User can search for a specific word or display all of the words and their frequenies in the text file until user quits.
*/
import java.util.*;
import java.io.*;
class Main {
  public static void main(String[] args) 
  {
    String fileName = "words.txt";
    int num = 0;
    
    TreeMap<String, Integer> nameList = readFile(fileName);
    //search(wordFile);
    //display(wordFile);
    while(num != 3)
    {
      menu();
      num = CheckInput.getIntRange(1,3);
      if(num == 1)
      {
        search(nameList);
      }
      if(num == 2)
      {
        display(nameList);
      }
    }     
  }

  /**
  * @param fileName takes in string objects
  * @return displays words and their frequenies from the text file.
  * Return the map populated with each of the words in the file and their frequenies.
  */
  public static TreeMap<String, Integer> readFile(String fileName)
  {
    TreeMap<String, Integer> wordFile = new TreeMap<String, Integer>();
    try{
      
      Scanner read = new Scanner(new File(fileName));
      while(read.hasNext())
      {
        String word = read.nextLine();
        int count = 0;
        
        if(wordFile.containsKey(word))
        {
          count = wordFile.get(word) + 1;
          wordFile.put(word, count);
        }
        else
        {
          count = 1; 
          wordFile.put(word, count);
        }    
      }
    }catch(FileNotFoundException fnf)
    {
      System.out.println("File was not found");
    }

    return wordFile;
  }

  /**
  * @param wordFile takes in string and integer objects
  * Prompt the user to enter a String. Displays the word with its frequency.
  */
  public static void search(TreeMap<String, Integer> wordFile)
  {
    String input = "";
    int count2 = 0;
    System.out.print("Enter word: ");
    input = CheckInput.getString();

    if(wordFile.containsKey(input))
    {
      count2 = wordFile.get(input) + 1;
      System.out.println(input + " => " + wordFile.get(input));
    }
    else
    {
      count2 = 0;
      System.out.println(input + " => " + count2);
    }
  }

  /**
  * @param wordFile takes in string and integer objects
  * Displays each of the words in the map
  with their frequenies from the text file.
  */
  public static void display(TreeMap<String, Integer> wordFile)
  {
    Set<String> keys = wordFile.keySet();
    for(String w: keys)
    {
      System.out.println(w + " => " + wordFile.get(w));
    }

  }

  /**
  * Displays the menu with options for user to choose from.
  */
  public static void menu()
  {
    System.out.println("1. Search");
    System.out.println("2. Display");
    System.out.println("3. Quit");
  } 
}