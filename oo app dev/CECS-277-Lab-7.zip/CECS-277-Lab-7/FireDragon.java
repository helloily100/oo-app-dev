public class FireDragon extends Dragon
{
  /*Initialize fireShots*/
  private int fireShots=4;

   /**
  * @param n initializes dragon's name
  * @param mHp initializes dragons's Hp
  */
  public FireDragon(String n, int mHp)
  { 
    super(n, mHp);
  
  }

 /**
  * if a fire dragon has any shots left return a random number in range 5- 9, else 0. Decrement the number shots if one is fired
  */
  public int fireShot()
  {
    if(fireShots >0)
    {
      fireShots--;
      return (int) (Math.random() *(9-5)) + 5;
      // return fireShots;
      // need to decrement
    }
    else
    {
      return 0;
    }

  }

  /**
   *String representation of the FireDragon Object
   *@return a string value of the fireshots
   */
  @Override
  public String toString()
  {
    return super.toString() + "\nFire shots remaining: " + fireShots;

  }

}