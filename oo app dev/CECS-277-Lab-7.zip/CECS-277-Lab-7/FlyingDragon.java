public class FlyingDragon extends Dragon
{
  /*Initialize swoops*/
  private int swoops=4;

   /**
  * @param n initializes dragon's name
  * @param mHp initializes dragon's Hp
  */
  public FlyingDragon(String n, int mHp)
  { 
    super(n, mHp);
  
  }

 /**
  * if a fire dragon has any swoop attacks left retrun a random number in range 5- 10, else 0. Decrement the number shots if one is used
  */
  public int swoopAttack()
  {
    if(swoops >0)
    {
      swoops--;
      return (int) ((Math.random() *(10-5)) + 5);
      // need to decrement
    }
    else
    {
      return 0;
    }

  }
  
  /**
   *String representation of the FlyingDragon Object
   *@return a string value of the swoops
   */
  @Override
  public String toString()
  {
    return super.toString() + "\nSwoop attacks remaining: " + swoops;

  }

}