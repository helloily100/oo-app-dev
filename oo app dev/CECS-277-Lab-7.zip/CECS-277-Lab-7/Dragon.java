public class Dragon
{
  /* Initialize name, hp, and maxHp*/
  private String name;
  private int hp;
  private int maxHp;

  /**
  * @param n intitialize a dragon's name 
  * @param mHp intitalize maxHp and hp
  * pass in the dragon's name and starting hit points
  */
  public Dragon(String n, int mHp)
  {
    name = n;
    maxHp = mHp;
    hp = mHp;
  }

  /**
  * @return the name of the dragon object
  */
  public String getName()
  {
    return name;
  }

   /**
  * @return the Hp of the dragon object
  */
  public int getHp()
  {
    return hp;
  }

   /**
  * @return a random amount of damage in the range 3- 7
  */
  public int attack()
  {
    return (int) ((Math.random() * (7-3)) + 3);
  }

   /**
  * @param d the amount of damage the dragon takes
  * subtract the value from the dragon's hp if the hp values is less than 0, reset to 0
  */
  public void takeDamage(int d)
  {
    hp = hp-d;    
    if (hp < 0)
    { 
      hp = 0;

    }
  }


  /**
  * @return the dragon's name and hp
  */
  @Override
  public String toString()
  {
    return name + ": " + hp + "/" + maxHp;
  }

}