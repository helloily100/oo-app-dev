/**
 * Name: Ivy Ly and Ayush Patel 
 * Date: 10/4/2021 
 * Description: A dragon game that allows the user to battle against dragons until they win or lose
 */
class Main {
  public static void main (String [] args){
    //create Dragon objects
    Dragon d1 = new Dragon("Deadly Nadder", 10);
    FireDragon d2 = new FireDragon("Gronckle", 15);
    FlyingDragon d3 = new FlyingDragon("Timberjack", 20);

    //initialize variables
    String player; 
    int playerHp = 50;
    int num1; 
    int num2;

    System.out.println("What is your name, challenger?");
    player = CheckInput.getString();
    System.out.println("Welcome to dragon training, " + player + "\nYou must defeat 3 dragons.");

    //while loop will run when player's Hp and all three dragon's Hp doesn't equal 0
    while (playerHp!=0 &&(d1.getHp()!=0||d2.getHp()!=0||d3.getHp()!=0)){ 
      
      System.out.println(player + " HP: " + playerHp);
      //attack dragon menu
      System.out.println("1. Attack " + d1);
      System.out.println("2. Attack " + d2);
      System.out.println("3. Attack " + d3);
      num1 = CheckInput.getIntRange(1,3);

      if(num1 == 1 && d1.getHp()==0){
        num1 = CheckInput.getIntRange(1,3);
      }
      if(num1 == 2 && d2.getHp()==0){
        num1 = CheckInput.getIntRange(1,3);
      }
      if(num1 ==3 && d3.getHp()==0){
          num1 = CheckInput.getIntRange(1,3);
      }

      //weapons menu
      System.out.println("Attack with: ");
      System.out.println("1. Arrow (1 D12)");
      System.out.println("2. Sword (2 D6)");
      num2 = CheckInput.getIntRange(1,2);

      if(num1 == 1 &&  num2 == 1 ){
        int damage = (int) ((Math.random() * (12-1)) + 1); //will generate a random number between 1 and 12
        System.out.println("You hit the dragon with your arrow.");
        d1.takeDamage(damage);
      }
      if (num1 == 1 && num2 == 2 ){
        int damage = (int) ((Math.random() * (6-1)) + 1) + (int) ((Math.random() * (6-1)) + 1); // will generate a randowm number between 1 and 6 twice and add them together
        System.out.println("You slash the dragon with your sword.");
        d1.takeDamage(damage);
      }
      if(num1 == 2 && num2 == 1 ){
        int damage = (int) ((Math.random() * (12-1)) + 1);
        System.out.println("You hit the dragon with your arrow.");
        d2.takeDamage(damage);
      }
      if (num1 == 2 && num2 == 2 ){
        int damage = (int) ((Math.random() * (6-1)) + 1) + (int) ((Math.random() * (6-1)) + 1);
        System.out.println("You slash the dragon with your sword.");
        d2.takeDamage(damage);
      }
      if(num1 == 3 && num2 == 1 ){
        int damage = (int) ((Math.random() * (12-1)) + 1);
        System.out.println("You hit the dragon with your arrow.");
        d3.takeDamage(damage);
      }
      if (num1 == 3 && num2 == 2 ){
        int damage = (int) ((Math.random() * (6-1)) + 1) + (int) ((Math.random() * (6-1)) + 1);
        System.out.println("You slash the dragon with your sword.");
        d3.takeDamage(damage);
      }

      int rand = (int)((Math.random() * (3-1)) + 1);
      // from here it will try and slect a random dragon and what attack it will caste on the user 
      if(rand == 1 && d1.getHp()!=0){
        System.out.println(d1.getName() + " smashes you with its tail.");
        playerHp = playerHp - d1.attack();   
      }

      if(rand == 2 && d2.getHp()!=0){     
        int rand2 = (int)((Math.random() * (10-1)) + 1);
          if (rand2 <= 4){
            System.out.println(d2.getName() + " smashes you with its tail.");
            playerHp = playerHp - d1.attack();
          }
          else{
            System.out.println(d2.getName() + " spews fire at you.");
            playerHp = playerHp - d2.fireShot();

          }
        }
        
      if(rand == 3 && d3.getHp()!=0){
            
          int rand2 = (int)((Math.random() * (10-1)) + 1);
          if(rand2 <=4 ){
             System.out.println(d3.getName() + " smashes you with its tail.");
             playerHp = playerHp - d1.attack();
          }
          else{
            System.out.println("swoops down and knocks you over.");
            playerHp = playerHp - d3.swoopAttack();
          }
        }
      else{
        rand = (int)((Math.random() * (3-1)) + 1);
        }
    }
      //prints out the results if the player wins or loses
      if (playerHp > 0 && (d1.getHp() == 0 && d2.getHp()== 0 && d3.getHp()== 0)){
        System.out.println();
        System.out.println("Congratulations " + player + "!");
        System.out.println("You defeated all three dragons.\nYou win!");
        }
      else{
        System.out.println("You lose.");
      }
    
  }
}