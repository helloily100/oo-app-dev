/** Die.java - representation of a single die. */
public class Die
{
   /* The number of sides of this die */
   private int sides;
   /* The value of this die */
   private int value;
   /** Default Constructor – creates a six-sided die.  */
   //  public Die( ) {
   //     sides = 6;
   //     roll();
   //  }
   /** Constructor - rolls to give the die an initial value
    *  @param s sets the number of sides of this die
    */
   public Die( int s ) {
      if( s > 1 ) {
         sides = s;
      } else {
         sides = 6;
      }
      roll();
   }
   /** Rolls the die
    *  @return value the die's value
    */
   public int roll() {
      value = (int)( Math.random() * sides ) + 1;
      // value = 1;
      return value;
   }
   /** Retrieve the die's value
    *  @return value the die's value
    */
   public int getValue() 
   {
      return value;
   }

   /**
   * @return boolean true if both the sides and value are the same
   */
   @Override
   public boolean equals(Object o)
   {
     Die d=(Die) o;
      if (this.value == d.value)
      { 
          return true;
      }
        return false;
   }

   /** 
   * @ param d takes Die object
   * @ return boolean true if the implicit die is less than the explicit die
   */
   public boolean lessThan(Die d)
   {
      if (this.value < d.value)
      {
       return true;
      }
      return false;
   }

   /**
   * @ param d takes Die object
   * @ return the difference between the implicit and explicit dice values
   */
   public int difference(Die d)
   {
      int diff = this.value - d.value;
      return diff;
    
   }
   /**
   *String representation of the Die Object
   *@return a string value of the die
   */
   @Override
   public String toString()
   {
      return "" + value;
   }
}

