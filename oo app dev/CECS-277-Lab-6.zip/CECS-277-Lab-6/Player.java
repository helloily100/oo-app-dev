/**
*Player.java- set of 3 dice that may be rolled
*/
public class Player
{
  /*The number of dice used in this game*/
  private final  int NUM_DICE = 3;

  /* The set of dice for the game*/
  private Die [] dice;
 
  /* Value of points given to the player*/
  private int points;

  /*Constructor- initializes each of the dice*/

  public Player()
  {
    dice = new Die[NUM_DICE];
    for (int i = 0; i < dice.length; i++)
    {
      dice[i] = new Die(0);
    }
  }

  /**
  * Sort the values of the three dice in ascending order
  */

  public void sort()
  {
    Die temp;
  
    if(dice[1].lessThan(dice[0]))
    {
      temp = dice[1];
      dice[1] = dice[0];
      dice[0] = temp;
      
    }
    if(dice[2].lessThan(dice[1]))
    {
      temp = dice[2];
      dice[2] = dice[1];
      dice[1] = temp;

    }
    if(dice[1].lessThan(dice[0]))
    {
      temp = dice[1];
      dice[1] = dice[0];
      dice[0] = temp;
    }
  }
  /**
  * Checks to see if all three of the dice values are the same and rewards the player with 3 points
  * @return boolean returns true if it is a three of a kind else it returns false
  */
  public boolean threeOfAKind()
  {
    if(dice[0].equals(dice[1])&& dice[1].equals(dice[2]))
    {
      points += 3;
      return true;
    }

    return false;
  }

  /**
  * Checks to see if all twi of the dice values are the same and rewards the player with 1 point
  *@return boolean returns true if it has a pair else returns false
  */
  public boolean pair()
  {
    if(dice[0].equals(dice[1]) || dice[0].equals(dice[2]))
    {
      points += 1;
      return true;
    }

    else if (dice[1].equals(dice[0])|| dice[1].equals(dice[2])){
       points += 1;
      return true;
    }
    else if (dice[2].equals(dice[0]) || dice[2].equals(dice[1])){
       points += 1;
       return true;
    }
    return false;
  }
  /**
  * Checks to see if the dice are in a series and rewards the player with 2 points
  * @return boolean returns true if it is a series else returns false
  */
  public boolean series()
  {
    if((dice[1].difference(dice[0])==1) && (dice[2].difference(dice[1])==1) && (dice[2].difference(dice[0])==2))
    {
      points += 2; 
      return true;
  
    }

    return false;
  }
  
  /* Rolls each of the three dice*/
  public void roll()
  {
    for(int i = 0; i < dice.length; i++)
    {
      dice[i].roll();
    }
    sort();
   
  }

  /**
  *@return points the player's points
  */
  public int getPoints()
  {
    return points;
  }

  /**
  *String representation of the Player Object
  *@return value a string presentation of the dice
  */
  @Override
  public String toString()
  {
    String values = "";
    for(int i = 0; i < dice.length; i++)
    {
      values += "D" + (i + 1) + ": " + dice[i] + " ";
    }

    return values;
  } 


}