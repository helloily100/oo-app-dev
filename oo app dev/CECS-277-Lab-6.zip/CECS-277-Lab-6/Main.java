/**
 * Name: Ivy Ly and Ayush Patel 
 * Date: 9/27/2021 
 * Description: A dice game that display the dice's value and points rewarded to the player
 */
class Main {
  public static void main(String[] args) {
    boolean input = true;
    System.out.println("Yahtzee");
    Player play = new Player();
    while (input) {
      System.out.print("Rolling Dice...");
      takeTurn(play);

      System.out.print("Play again? (Y/N)");
      input = CheckInput.getYesNo();
      System.out.println();

    }

    System.out.println("Game Over.\nFinal Score = " + play.getPoints() + " points");

  }

  /**
   * @param play1 takes Player object calls methods from the Player class and displays it
   */
  public static void takeTurn(Player play1) {

    play1.roll();
    System.out.println(play1);

    if (play1.threeOfAKind()) {
      System.out.println("You got 3 of a kind!");
      System.out.println("Score = " + play1.getPoints());

    } else if (play1.pair()) {
      System.out.println("You got a pair!");
      System.out.println("Score = " + play1.getPoints());

    } else if (play1.series()) {
      System.out.println("You got a series!");
      System.out.println("Score = " + play1.getPoints());
    } else {
      System.out.println("Aww. Too bad.");
      System.out.println("Score = " + play1.getPoints());
    }
  }
}