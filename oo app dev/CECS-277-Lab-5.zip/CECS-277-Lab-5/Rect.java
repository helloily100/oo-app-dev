public class Rect
{
  private int x; 
  private int y; 
  private int width;
  private int height;

  /**
  * @param w the width coordinate of the new point
  * @param h the height coordinate of the new point
  */
  public Rect (int w, int h)
  {
    width = w;
    height = h;
  }

  /**
  * returns the x value respectively
  */
  public int getX()
  {
    return x;
  }
  
  /**
  * reutrns the y value respectively
  */
  public int getY()
  {
    return y;
  }

  /**
  *@param dx amount to move this point in x direction 
  *@param dy amount to move this point in y direction
  */
  public void translate(int dx, int dy)
  {
    x += dx;
    y += dy;
  }
  
}