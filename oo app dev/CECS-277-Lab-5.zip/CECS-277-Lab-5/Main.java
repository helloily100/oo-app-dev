                                                                                                                    /**
* Name: Ivy Ly and Shadman Zahir
* Date: 9/22/2021
* Description: allow user to input the width and height of a rectangle that will display on a grid and move around the grid
*/
class Main {
  public static void main(String[] args)
  {
    String [][] user_grid = new String [20][20];
    int widthInput = 0;
    int heightInput = 0;
    int choice = 0;
    boolean valid = true;

    //Rect r1 = new Rect (0,0);
    //r1.translate(0,0);
   
    System.out.print("Enter rectangle width (1-5)? ");
    widthInput = CheckInput.getIntRange(1,5);
    System.out.print("Enter rectangle height (1-5)? ");
    heightInput = CheckInput.getIntRange(1,5);
    
   
   
    displayGrid(user_grid);
    placeRect(user_grid, widthInput, heightInput);
    resetGrid(user_grid);
     
    while(choice != 5)
    { 
      System.out.println("Enter direction: ");
      menu();
      choice = CheckInput.getIntRange(1,5);
      
    }

  }
  /**
  * @param grid display 20x20 grid
  * fill it with "."
  */
  public static void  displayGrid(String [][] grid) {
    for(int i = 0; i < grid.length; i++) {
      for(int j = 0; j < grid[0].length; j++)
      {
        grid[i][j] = ". ";
        System.out.print(grid[i][j]);
      }
      System.out.println();
    }
  }

  /**
  *@param grid display 20x20 grid
  *@param widthInput takes in the user's input for width 
  *@param heightInput takes in the user's input for height
  */
  public static void placeRect(String [][] grid, int widthInput, int heightInput)
  { 
     int w = widthInput;
     int h = heightInput;
     //Rect r1 = new Rect (0,0);
     //r1.translate(0,0);

     for(int i = 0; i <= h-1; i++) 
     {
      for(int j = 0; j <= w-1; j++)
      {
          grid[h][w] = "* ";
          System.out.print(grid[h][w]);
      }
      System.out.println();
     }
     

  }

  /**
  *@param grid display 20x20 grid
  * fill it with "."
  */
  public static void resetGrid(String [][] grid)
  {
     for(int i = 0; i < grid.length; i++) {
      for(int j = 0; j < grid[0].length; j++)
      {
        if(grid[i][j] == "* ")
        {
          grid[i][j] = ". ";
          System.out.print(grid[i][j]);
        }
        else
        {
          grid[i][j] = ". ";
          System.out.print(grid[i][j]);
        }
        
      }
      System.out.println();
    }

  }

  /**
  * display menu with options to move the rectangle
  */
  public static void menu()
  {
    System.out.println("1. Up");
    System.out.println("2. Down");
    System.out.println("3. Left");
    System.out.println("4. Right");
    System.out.println("5. Quit");
  }
}