public class Tiger extends Cat
{
  /**
  * @ param n calls for name from superclass
  */
  public Tiger(String n)
  {
    super(n);
  }
  
  /**
  *Description: player passes through to feed tiger if it is hungry. If not hungry then tiger will attack player.
  *@param p: player
  */
  @Override
  public String feed(Player p)
  {
    if(getHunger() > 10)
    {
      p.takeDamage(8); //decrements health of player
      return getName() + " is full and attacked you for 8 hp with its terrifying claws.\n";
    }
    else
    {
      incrementHunger(5); //increments cat hunger
      return getName() + " has been feed successfully. 5 incremented hunger.\n";
    }
  }

  /**
  *Description: player passes in to play with tiger if tiger is not hungry. if tiger is hungry then player will be attacked by tiger.
  *@param p: player
  */
  public String play(Player p)
  {
    if(getHunger() < 4)
    {
      p.takeDamage(8); //decrements player health
      return getName() + " is mad because " + getName() + " is hungry."+ getName()+ " hits you for 8 hp.\n";
    }
    if(4 <= getHunger() && getHunger() <= 6)
    {
      incrementHunger(-3); //decrements cat hunger
      return getName() + " plays with a car tire you threw at him. 3 decremented hunger.\n";
    }
    if(7 <= getHunger() && getHunger() <= 8)
    {
      incrementHunger(-3); //decrements cat hunger
      return getName() + " plays tug of war with you. 3 decremented hunger.\n";
    }
    else
    {
      incrementHunger(-2); //decrements cat hunger
      return getName() + " plays with laser pointer you have. 2 decremented hunger.\n";
    }
  }

  /**
  *Description: player passes in and pets tiger if tiger is not hungry. if tiger is hungry then player is attacked by tiger.
  *@param p: player
  */
  public String pet(Player p)
  {
    if(getHunger() < 4)
    {
      p.takeDamage(8); //decrements player health
      return getName() + " is mad because "+ getName()+ " is hungry. "+ getName()+ " hits you for 8 hp.\n";
    }
    if(4 <= getHunger() && getHunger() <= 9)
    {
      incrementHunger(-2); //decrements cat hunger
      return getName() + " is happy you pet him/her :). 2 decremented hunger.\n";
    }
    else
    {
      incrementHunger(-2); //decrements cat hunger
      return getName() + " purrs and goes to sleep. 2 decremented hunger.\n";
    }
  }
}