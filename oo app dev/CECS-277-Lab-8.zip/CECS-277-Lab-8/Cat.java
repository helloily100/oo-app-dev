public abstract class Cat
{
  private String name;
  private int hunger;

  /**
  *Description: The string passed in will be stored in string name
  *@param n: name of cat the user picks.
  */
  public Cat(String n)
  {
    name = n;
  }

  /**
  *Description: returns name of cat
  *@return String name
  */
  public String getName()
  {
    return name;
  }

  /**
  *Description: returns number in hunger
  *@return int hunger
  */
  public int getHunger()
  {
    
    return hunger;
  }

  /**
  *Description: the value will either be added or subtracted from hunger 
  *@param val: hunger incremented
  *@return int hunger
  */
  public int incrementHunger(int val)
  {
    hunger += val;
    if (hunger < 1){
      hunger = 1;
    }
    if(hunger > 10)
    {
      hunger = 10;
    }
    return hunger;

  }

  @Override
  public String toString()
  {
    if(getHunger() >= 10)
    {
      return "" + getName() + " is full";
    }
    if(4 <= getHunger() && getHunger() <= 9 )
    {
      return "" + getName() + " is satisfied";
    }
    if (getHunger() <= 3)
    {
      return "" + getName() + " is hungry";
    }
    
    //error checking
    return "";
    
  }
  
  public abstract String feed(Player p);
  public abstract String play(Player p);
  public abstract String pet(Player p);

}