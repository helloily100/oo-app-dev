public class Ocelot extends Cat 
{
  /**
  * @ param n calls for name from superclass
  */
  public Ocelot(String n)
  {
    super(n);
    
  }
  
  /**
  *Description: player passes through to feed cat if it is hungry. If not hungry then cat will attack player
  *@param p: player
  */
  @Override
  public String feed(Player p)
  {
    if(getHunger() > 10)
    {
      p.takeDamage(3); //decrements player ho
      return getName() + " is full and attacked you for 3 hp with its big claws.\n";
    }
    else
    {
      incrementHunger(6); //increments cat hunger
      return getName() + " has been feed successfully. 6 incremented hunger.\n";
    }
  }

  /**
  *Description: player passes in to play with cat if cat is not hungry. if cat is hungry then player will be attacked by cat
  *@param p: player
  */
  public String play(Player p)
  {
    if(getHunger() < 4)
    {
      p.takeDamage(3); //decrements player hp
      return getName() + " is mad because "+ getName()+ " is hungry. " + getName() + " hits you for 3 hp.\n";
    }
    if(4 <= getHunger() && getHunger() <= 7)
    {
      incrementHunger(-3); //decrements cat hunger
      return getName() + " plays with your shoe. 3 hunger decremented.\n";
    }
        if(7 <= getHunger() && getHunger() <= 8)
    {
      incrementHunger(-3); //decrements cat hunger
      return getName() + " plays with a piece of a bone with you. 3 decremented hunger.\n";
    }
    else
    {
      incrementHunger(-3); //decrements cat hunger
      return getName() + " plays with a bundle of toy mice. 3 decremented hunger.\n";
    }
  }

  /**
  *Description: player passes in and pets cat if cat is not hungry. if cat is hungry then player is attacked by cat.
  *@param p: player
  */
  public String pet(Player p)
  {
    if(getHunger() < 4)
    {
      p.takeDamage(2); //decrements player hp
      return getName() + " is mad because "+ getName()+ " is hungry. "+ getName() + " hits you for 2 hp.\n";
    }
    if(4 <= getHunger() && getHunger() <= 9)
    {
      incrementHunger(-2); // decrements cat hunger
      return getName() + " is happy you pet him/her :). 2 decremented hunger.\n";
    }
    else
    {
      incrementHunger(-1); //decrements cat hunger
      return getName() + " purrs and goes to sleep. 1 decremented hunger.\n";
    }
  }
  
}