/**
* Name: Ivy Ly and Juan Perez
* Date: 10/11/2021
* Description: A cat game that allows the player to choose a cat and interact with the cat until the player runs out of hp
*/
class Main {
  public static void main(String[] args)
  { 
    //initialize player object
    Player p = new Player(10);
    
    System.out.println("Choose a kitty:");
    System.out.println("1. Tabby Cat");
    System.out.println("2. Ocelot");
    System.out.println("3. Tiger");
    int input = CheckInput.getIntRange(1,3);
    System.out.print("Name your kitty: ");
    String catName = CheckInput.getString();

    //initialize cat objects
    Cat c1 = new Tabby(catName);
    Cat c2 = new Ocelot(catName);
    Cat c3 = new Tiger(catName);

    //the while loop will run until player runs out of hp
    while(p.getHp() != 0)
    {
      System.out.println(p);
      if(input == 1)
      {
        catName = c1.getName();
        interactCat(c1, p);
      }
      if(input == 2)
      {
        catName = c2.getName();
        interactCat(c2, p);
      }
      if(input == 3)
      {
        catName = c3.getName();
        interactCat(c3, p);
      }
    }
    if(p.getHp() == 0)
    { 
      System.out.println("Sorry you lose.");

    } 
  }

  /**
  * @param c takes Cat objects
  * @param p takes Player objects
  * Displays the cat interaction menu, allow user's input, and calls the corresponding cat method and the displays the string
  */
  public static void interactCat(Cat c, Player p)
  {
    int playerInput;
    System.out.println(c.toString());
    System.out.println("1. Feed your cat");
    System.out.println("2. Play with your cat");
    System.out.println("3. Pet your cat");
    playerInput = CheckInput.getIntRange(1,3);
  
    if(playerInput == 1)
    { 
      System.out.print(c.feed(p));
    }
    if(playerInput == 2)
    {
      System.out.print(c.play(p));
    }
    if(playerInput == 3)
    {
      System.out.print(c.pet(p));
    }


  } 

  //this is already in the CheckInput class
  /**
  public static int getIntRanger(int low, int high)
  {

  }
  */
}
