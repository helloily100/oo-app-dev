public class Player 
{
  /* Initialize hp and maxHp */
  private int hp;
  private int maxHp;

  /**
  * @param mHp intitalize maxHp and hp
  * pass in the player's starting hit points
  */
  public Player(int mHp)
  {
    hp = mHp;
    maxHp = mHp;

  }

  /**
  * @return the Hp of the player object
  */
  public int getHp()
  {
    return hp;
  }
  
  /**
  * @param d the amount of damage the player takes
  * subtract the value from the player's hp if the hp values is less than 0, reset to 0
  */
  public void takeDamage(int d)
  {
    hp = hp - d;    
    if (hp < 0)
    { 
      hp = 0;

    }
  }

  /**
  * @return the players's hp
  */
  @Override
  public String toString()
  {
    return "You have " + hp + "/" + maxHp + " HP";
  }
}