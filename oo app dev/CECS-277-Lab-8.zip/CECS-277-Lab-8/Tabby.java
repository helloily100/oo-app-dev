public class Tabby extends Cat

/**
* @ param n calls for name from superclass
*/
{
  public Tabby(String n)
  {
    super(n);
    
  }
  
  /**
  *Description: player passes through to feed tabby if it is hungry. If not hungry then tabby will attack player
  *@param p: player
  */
  @Override
  public String feed(Player p)
  {
    if(getHunger() > 10)
    {
      p.takeDamage(2); //decrements player hp
      return getName() + " is full and attacked you for 2 hp with its tiny claws.\n";
    }
    else
    {
      incrementHunger(2); //increments cat hungrr
      return getName() + " has been feed successfully. 2 incremented hunger.\n";
    }
  }

  /**
  *Description: player passes in to play with tabby if tabby is not hungry. if tabby is hungry then player will be attacked by tabby.
  *@param p: player
  */
  public String play(Player p)
  {
    if(getHunger() < 4)
    {
      p.takeDamage(1); //descrements player hp
      return getName() + " is mad because "+getName()+ " is hungry."+ getName()+ " hits you for 1 hp.\n";
    }
    if(4 <= getHunger() && getHunger() <= 7)
    {
      incrementHunger(-2); //decrements cat hunger
      return getName() + " plays with a stick. 2 decremented hunger.\n";
    }
    if(7 <= getHunger() && getHunger() <= 8)
    {
      incrementHunger(-2); //decrements cat hunger
      return getName() + " plays with a rope with you. 2 decremented hunger.\n";
    }
    else
    {
      incrementHunger(-2); //decrements cat hunger
      return getName() + " plays with a toy mouse. 2 decremented hunger.\n";
    }
  }

  /**
  *Description: player passes in and pets tabby if tabby is not hungry. if tabby is hungry then player is attacked by tabby.
  *@param p: player
  */
  public String pet(Player p)
  {
    if(getHunger() < 4)
    {
      p.takeDamage(1); //decrements player hp
      return getName() + " is mad because "+getName()+ " is hungry. "+ getName()+ " hits you for 1 hp.\n";
    }
    if(4 <= getHunger() && getHunger() <= 9)
    {
      incrementHunger(-2); //decrements cat hunger
      return getName() + " is happy you pet him/her :). 2 decremented hunger.\n";
    }
    else
    {
      incrementHunger(-1); //decrements cat hunger
      return getName() + " purrs and goes to sleep. 1 decremented hunger.\n";
    }
  }
}