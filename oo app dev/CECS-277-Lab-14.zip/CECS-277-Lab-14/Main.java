/**
* Name: Ivy Ly and Ayush Patel 
* Date: 12/6/2021
* Description: A puppy simulator that performs two basic functions: feed or play.
*/
class Main {
  public static void main(String[] args) {
    
    Puppy p = new Puppy();
    boolean check = true;
    int input = 0; 

    System.out.println("Congratulations on your new puppy!");

    // The while- loop will run until input is 3
    while(check)
    {
      System.out.println("What would you like to do?");
      System.out.println("1. Feed\n2. Play\n3. Quit");
      input = CheckInput.getIntRange(1,3);
      if(input == 1)
      {
        System.out.println(p.giveFood());
      }
      else if(input == 2)
      {
        System.out.println(p.throwBall());
      }
      else if(input == 3)
      {
        check = false;
      }
    }
   
  }
}