public class EatingState implements PuppyState
{
  /**
  * If the puppy is eating, it can play
  * @param p - takes Puppy object
  * @return a string statement
  */
  @Override
  public String play(Puppy p)
  {
    int play = p.incPlays();
    if (play >= 1)
    {
      p.setState( new PlayState());
    }
    return "The puppy looks up from its food and chases the ball you threw.";
  }

  /**
  * The puppy will continue to eat until it falls back to sleep
  * @param p - takes Puppy object
  * @return a string statement
  */
  @Override
  public String feed(Puppy p)
  {
    int food = p.incFeeds();
    if (food >= 3) 
    {
      p.setState(new AsleepState());
      p.reset();
      return "The puppy continues to eat as you add another scoop of kibble to its bowl.\nThe puppy ate so much it fell asleep!";
    }
    return "The puppy continues to eat as you add another scoop of kibble to its bowl.";
  }
}