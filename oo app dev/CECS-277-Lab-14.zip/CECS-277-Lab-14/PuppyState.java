public interface PuppyState
{
  /** The following will be overwritten in the implementing classes*/
  public String play(Puppy P);
  public String feed(Puppy p);
}