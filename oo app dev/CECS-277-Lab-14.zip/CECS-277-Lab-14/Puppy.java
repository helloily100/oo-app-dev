public class Puppy
{
  //initialize PuppyState object and variables
  private PuppyState state; 
  private int numFeeds;
  private int numPlays; 

  /**
  * Constructor method
  */
  public Puppy()
  {
    numFeeds = 0;
    numPlays = 0;
    state = new AsleepState();
  }

  /** 
  * Set the variable state to equal PuppyState object s 
  * @param s - takes PuppyState object
  */
  public void setState( PuppyState s)
  {
    state = s;

  }

  /**
  * Will call the play method
  */
  public String throwBall()
  {
    return state.play(this);
  }

  /**
  * Will call the feed method
  */
  public String giveFood()
  {
    return state.feed(this);
  }

  /**
  * Increment the number of times the puppy has been fed
  * @return the incremented times the puppy has been fed
  */
  public int incFeeds()
  {
    return numFeeds++;
  }

  /**
  * Increment the number of times the puppy has played
  * @return the incremented times the puppy has played
  */
  public int incPlays()
  {
    return numPlays++;
  }

  /**
  * Will call the feed method
  */
  public void reset()
  {
    numFeeds = 0;
    numPlays = 0;
  }


}