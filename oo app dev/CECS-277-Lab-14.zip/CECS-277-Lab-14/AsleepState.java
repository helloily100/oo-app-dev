public class AsleepState implements PuppyState
{
  /**
  * If the puppy is asleep, the puppy can't play
  * @param p - takes Puppy object
  * @return a string statement
  */
  @Override
  public String play(Puppy p)
  {
    return "The puppy is asleep. It doesn't want to play right now.";
  }
  
  /**
  * If the puppy is alseep, it will wake up to eat
  * @param p - takes Puppy object
  * @return a string statement
  */
  @Override
  public String feed(Puppy p)
  {
    p.setState( new EatingState());
    p.incFeeds();
    return "The puppy wakes up and comes running to eat.";
    
  }
}