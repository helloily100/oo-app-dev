/** 
* Names: Ivy Ly and Michael Lav 
* Date: 8/30/2021 
* Description: user enters a zip code and the bar code for that zip code is printed out
*/
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        printBarCode(getZip());
        }
 /** 
  * Get user input for a 5- digit zip code
*/
    public static String getZip() {
        System.out.print("Enter a zip code: ");
        Scanner in = new Scanner(System.in);
        int zipCode = 0;
        String sZip = "placeholder";
        boolean valid = false;
        while (!valid) {
            if(in.hasNextInt()){
                zipCode = in.nextInt();
                if (zipCode >= 10000 && zipCode <= 99999) {
                    //convert into string
                    sZip = "" + zipCode;
                    valid = true;
                } else {
                    System.out.print("Please enter a valid zipcode: ");
                }
            }else {
                System.out.print("Please enter a valid zipcode: ");
                in.next();
            }
        }
        return sZip;
    }
  /** 
  * @ param d assign the value to a bar code
  */ 

    public static void printDigit(char d){
        if (d == '1'){
            System.out.print("...||");
        } else if (d == '2'){
            System.out.print("..|.|");
        } else if (d == '3'){
            System.out.print("..||.");
        } else if (d == '4'){
            System.out.print(".|..|");
        } else if (d == '5'){
            System.out.print(".|.|.");
        } else if (d == '6'){
            System.out.print(".||..");
        } else if (d == '7'){
            System.out.print("|...|");
        } else if (d == '8'){
            System.out.print("|..|.");
        } else if (d == '9'){
            System.out.print("|.|..");
        } else if (d == '0'){
            System.out.print("||...");
        }
    }

  /**  
  * @ para zip calculates the check digits
  */
    public static char getCheckDigit(String zip){
        int sum = 0;
        for(int i = 0; i < zip.length(); i++) {
            char digits = zip.charAt(i);
            sum = sum + digits - 48;
            }if (sum <= 10){
                sum = 10 - sum;
            } else if (sum > 10 && sum <= 20){
                sum = 20 - sum;
            }else if (sum > 20 && sum <= 30){
                sum = 30 - sum;
            }else if (sum > 30 && sum <= 40){
                sum = 40 - sum;
            }else if (sum > 40 && sum <= 50){
                sum = 50 - sum;
            }
        //convert int to char
        return ((char)(sum+48));
        }
  /**  
  * Prints zip code and bar code
  */

    public static void printBarCode(String zip){
        System.out.print("|");
        for(int i = 0; i < zip.length(); i++) {
            char digits = zip.charAt(i);
            printDigit(digits);
        }
        printDigit(getCheckDigit(zip));
        System.out.print("|");
    }
}
