/** 
* Name: Ivy Ly and Juan Perez 
* Date: 9/13/2021
* Description: Display stats on US states and population
*The program starts of by reading the text file titled as StatePops. The program will read the file and make two lists from the text file. One listStates will have the name of the States while listpops will have the number of populations in their state.Then program will allow for the user to chose from 5 option from the main menu. The options the program starts from option 1 in where the program will sort the states in alphabetical order. option 2 will order the states from their number of populations from low to high. option 3 will show the total sum of all the population numbers in listpops. option 4 will allow the user to input a number from 0-_____. the program will show the states with a greater population number than the number the user inputed. finally option 5 will quit the program.
*/
import java.util.ArrayList;
import java.util.Scanner;
import java.text.DecimalFormat;
import java.lang.*;
import java.io.*;
class Main {
  public static void main(String[] args) 
  {
    ArrayList <String> listStates = new ArrayList <String> ();
    ArrayList <Integer> listpops = new ArrayList <Integer> ();
    
    readFile(listStates, listpops);
    menu(listStates, listpops);
  }

  public static void readFile(ArrayList <String> listStates, ArrayList <Integer> listpops) 
  {
    try{
      Scanner read = new Scanner (new File ("StatePops.txt") );
      
      while(read.hasNext())
      {
        String states = read.nextLine();
        String [] list = states.split(",");

        for(int i = 0; i < list.length;
        i++)
        {
          if(i % 2 == 0){

           //System.out.println (list[i]);  
           listStates.add(list[i]);
          }  

          else{
            int num = Integer.parseInt(list[i]); 
            listpops.add(num);
          }
        }

      } 
     
      //read.close();
    }catch( FileNotFoundException fnf)
    {
      System.out.println("File was not found");

    }
   
  }

  /**
  * @param listStates list the states in the US
  * @param listpops list the population of the states 
  * lists the states in alphabetical order
  */
  public static void sortStates(ArrayList <String> listStates, ArrayList <Integer> listpops) 
  {
    DecimalFormat df1 = new DecimalFormat("#,###");
    boolean swapped = false;
    do
    {
      swapped = false;
      for( int i = 0; i < listStates.size() - 1; i++ )
      {
        if( listStates.get( i ).compareToIgnoreCase(listStates.get( i + 1 )) > 0 )
        {
            String swap = listStates.get( i );
            listStates.set( i, listStates.get( i + 1 ) );
            listStates.set( i + 1, swap );
            swapped = true; 
            
            int swapnum = listpops.get( i );
            listpops.set( i, listpops.get( i + 1 ) );
            listpops.set( i + 1, swapnum );
            swapped = true; 
                
        }

      }
    } while( swapped );
    
    /**
    for(int i = 0; i < listStates.size(); i++ )
    {
        System.out.println(listStates.get(i) + " " + df1.format(listpops.get(i)));  
    }
    */
     
  }

  /**
  * @param listStates list the states in the US
  * @param listpops list the population of the states 
  * lists the populations in ascending order
  */
   public static void sortPopulation(ArrayList <String> listStates, ArrayList <Integer> listpops)
   {
      DecimalFormat df1 = new DecimalFormat("#,###");
      boolean swapped = false;
      do 
      {
        swapped = false;
        for( int i = 0; i < listpops.size() - 1; i++ )
         {
          if( listpops.get( i ) > listpops.get( i + 1 ) )
         {

            String swap = listStates.get( i );
            listStates.set( i, listStates.get( i + 1 ) );
            listStates.set( i + 1, swap );
            swapped = true; 

            int swapnum = listpops.get( i );
            listpops.set( i, listpops.get( i + 1 ) );
            listpops.set( i + 1, swapnum );
            swapped = true;
          }
       
        }
      } while( swapped );

      /**
      for(int i = 0; i < listpops.size(); i++ )
      {
        System.out.println(listStates.get(i) + " " + df1.format(listpops.get(i)));
      }
      */
      
   }

  /**
  * @param listStates list the states in the US
  * @param listpops list the population of the states 
  * displays the states and their corresponding population size
  */
  public static void displayStates(ArrayList <String> listStates, ArrayList <Integer> listpops) 
  {
    DecimalFormat df1 = new DecimalFormat("#,###");
    
    for(int i = 0; i < listStates.size(); i++ )
    {
      System.out.println(listStates.get(i) + " " + df1.format(listpops.get(i)));
    }
  
  }
  
  /** total sum passes in the population list and adds them up to display the totalsum of the population list
  *@param listpops list the population of the states
  */
  public static int totalSum(ArrayList <Integer> listpops)
  {
  
    DecimalFormat df1 = new DecimalFormat("#,###");
     //format to display commas for thousand, millions, and billions
    int totalSum = 0;
     //initializes totalsum 
    for(int i = 0; i < listpops.size(); i++){
     // for loop  loop through all the numbers in listpops to sum together
      totalSum = totalSum + listpops.get(i);
      //sums all numbers from listpops to totalsum
    }
    System.out.print("US Population = ");
    System.out.println(df1.format(totalSum));
     //prints out the total sum of the US populations

    return totalSum;
  }

  /**populationsGreater asks the user to input a number. Once the value is inputed the method will show the states that have a population greater than the users inputed number.
  *@param listStates list the states of the US
  *@param listpops list the populations of the states
  */
  public static void popultaionGreater(ArrayList <String> listStates, ArrayList <Integer> listpops)
  {
    DecimalFormat df1 = new DecimalFormat("#,###");
     //format to display commas for thousand, millions, and billions
    System.out.print("Enter Population: ");
     
    int usernum = CheckInput.getPositiveInt();
     //makes sure to get a valid response from the user
    for (int i = 0; i < listpops.size(); i++){
     //for loop to scan through listpops
      int checknum = listpops.get(i);
       ///tranfers the values from listpops to see the values
      if (usernum < checknum){
        //if the users number is lesser than a number from listpops then it will display the number and the coressponding state
        System.out.println(listStates.get(i)+ " " + df1.format(listpops.get(i)) );
      }
    }


  }

  /**
  * @param listStates list the states in the US
  * @param listpops list the population of the states 
  * allow user input to determine what should be displayed on the screen
  */
  public static void menu(ArrayList <String> listStates, ArrayList <Integer> listpops)
  {
    int choice = 0; 

    while (choice != 5)
    {
      System.out.println("State Stats");
      System.out.println("1. Display Sorted States");
      System.out.println("2. Display Sorted Populations");
      System.out.println("3. Display Total US Population");
      System.out.println("4. Display States with Population Greater Than");
      System.out.println("5. Quit");
      choice = CheckInput.getIntRange(1,5); 
 
      if(choice == 1)
      {
        sortStates(listStates, listpops);
        displayStates(listStates, listpops);
      }
      else if(choice == 2)
      {
        sortPopulation(listStates, listpops); 
        displayStates(listStates, listpops);      
      }
      else if(choice == 3)
      {
        totalSum(listpops);
      }
      else if(choice == 4)
      {
        popultaionGreater(listStates, listpops);
      }
      else if(choice == 5)
      {
        System.out.println("Exiting");
      }
    }
  }
}