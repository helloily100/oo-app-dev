public class Undead extends Monster
{
  /**
  * Construtor method
  * Give monster a name and hp
  */
  public Undead()
  {
    super("Undead", 4);
  }

  /**
  * Give monster an attack damage
  * @return attack damage
  */
  @Override
  public int attack()
  {
    int atk = 2;
    return atk;
  }
}