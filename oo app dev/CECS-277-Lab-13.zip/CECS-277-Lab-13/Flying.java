public class Flying extends MonsterDecorator 
{
  /**
  * Constructor method
  * @param m - take Monster object 
  */
  public Flying(Monster m)
  {
    super(m, "Flying " + m.getName(), m.getHp() + 4);

  }
  
  /**
  * Give monster additional attack damage
  * @return updated attack damage
  */
  @Override
  public int attack()
  {
    int atk = 2;
    return atk + super.attack();
  }
}