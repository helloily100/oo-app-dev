public class Poison extends MonsterDecorator 
{
  /**
  * Constructor method
  * @param m - take Monster object 
  */
  public Poison(Monster m)
  {
    super(m, "Poison Fanged " + m.getName() , m.getHp() + 1);
  }


  /**
  * Give monster additional attack damage
  * @return updated attack damage
  */
  @Override
  public int attack()
  {
    int atk = 5;
    return atk + super.attack();
  }
}