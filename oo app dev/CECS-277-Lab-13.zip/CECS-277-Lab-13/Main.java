/**
* Name: Ivy Ly and Ayush Patel 
* Date: 11/29/2021
* Description: Allow user to choose a base monster, add decorations to name, update hp, and update attack damage
*/
class Main {
  public static void main(String[] args) {
    
    // initialize variable and Monster object
    int choice2 = 0;
    Monster m;
    // base monster menu
    System.out.println("Monster Creator!");
    System.out.println("Choose a base monster: ");
    System.out.println("1. Alien");
    System.out.println("2. Beast");
    System.out.println("3. Undead");
    int choice = CheckInput.getIntRange(1,3);

    if(choice == 1)
    {
      m = new Alien();
      System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
    }
    else if(choice == 2)
    {
      m = new Beast();
      System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
    }
    else
    {
      m = new Undead();
      System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
    }

    while(choice2 != 5)
    {
      //ability menu
      System.out.println("Add an ability: ");
      System.out.println("1. Fire");
      System.out.println("2. Flying");
      System.out.println("3. Lasers");
      System.out.println("4. Posion");
      System.out.println("5. Quit");
      choice2 = CheckInput.getIntRange(1,5); 

      //Alien
      if((choice == 1) && (choice2 == 1) )
      {
        m = new Fire(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");  
             
      }
      else if((choice == 1)  && (choice2 == 2))
      {
        m = new Flying(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
      }
      else if((choice == 1)  && (choice2 == 3))
      {
        m = new Lasers(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
      }
      else if((choice == 1)  && (choice2 == 4))
      {
        m = new Poison(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
      }

      //Beast
      else if((choice == 2)  && (choice2 == 1))
      {
        m = new Fire(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
      }
      else if((choice == 2)  && (choice2 == 2))
      {
        m = new Flying(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
      }
      else if((choice == 2)  && (choice2 == 3))
      {
        m = new Lasers(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
      }
      else if((choice == 2)  && (choice2 == 4))
      {
        m = new Poison(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
      }

      //Undead
      else if((choice == 3)  && (choice2 == 1))
      {
        m = new Fire(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
      }
      else if((choice == 3)  && (choice2 == 2))
      {
        m = new Flying(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
      }
      else if((choice == 3)  && (choice2 == 3))
      {
        m = new Lasers(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
      }
      else if((choice == 3)  && (choice2 == 4))
      {
        m = new Poison(m);
        System.out.println(m.getName()+ " has " + m.getHp() + " hp, and attacks for "+ m.attack() + " damage.");
      }
    }
  }
}