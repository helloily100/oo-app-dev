public class Beast extends Monster
{
  /**
  * Construtor method
  * Give monster a name and hp
  */
  public Beast()
  {
    super("Beast", 5);
  }

  /**
  * Give monster an attack damage
  * @return attack damage
  */
  @Override
  public int attack()
  {
    int atk = 4;
    return atk;
  }
}