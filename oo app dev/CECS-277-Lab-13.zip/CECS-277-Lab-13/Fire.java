public class Fire extends MonsterDecorator 
{
  /**
  * Constructor method
  * @param m - take Monster object 
  */
  public Fire(Monster m)
  {
    super(m, "Firey " + m.getName(), m.getHp() + 3);

  }

  /**
  * Give monster additional attack damage
  * @return updated attack damage
  */
  @Override
  public int attack()
  {
    int atk = 3;
    return atk + super.attack();
  }
}