public abstract class Monster
{
  //initialize variables
  private int hp;
  private String name; 
  
  /**
  * Constructor method
  * @param n - Monster's name 
  * @param h - Monster's hp 
  */
  public Monster(String n, int h)
  {
    name = n; 
    hp = h;

  }

  /**
  * Monster's name
  * @return the name of the monster's name
  */
  public String getName()
  {
    return name;
  }

  /**
  * Monster's hp
  * @return the monster's hp
  */
  public int
  getHp()
  {
    return hp;

  }

  /**
  * abstract attack method that doesn't take a body of code
  */
  public abstract int attack();

}