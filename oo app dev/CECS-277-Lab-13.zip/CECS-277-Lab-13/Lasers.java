public class Lasers extends MonsterDecorator 
{
  /**
  * Constructor method
  * @param m - take Monster object 
  */
  public Lasers(Monster m)
  {
    super(m, m.getName() + " with Laser beams", m.getHp() + 5);
  }

  /**
  * Give monster additional attack damage
  * @return updated attack damage
  */
  @Override
  public int attack()
  {
    int atk = 4;
    return atk + super.attack();
  }
}