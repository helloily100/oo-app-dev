public class Alien extends Monster
{
  /**
  * Construtor method
  * Give monster a name and hp
  */
  public Alien()
  {
    super("Alien", 4);
  }
  
  /**
  * Give monster an attack damage
  * @return attack damage
  */
  @Override
  public int attack()
  {
    int atk = 1;
    return atk;
  }
}