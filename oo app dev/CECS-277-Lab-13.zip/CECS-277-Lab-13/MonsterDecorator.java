public abstract class MonsterDecorator extends Monster
{
 // initialize Monster object
 private Monster monster;

 /**
 * Constructor method
 * @param m - take Monster object 
 * @param addName - add addtional decoration to monster's name 
 * @param addHp - add additional hp
 */
 public MonsterDecorator(Monster m, String addName, int addHp)
 {
   super(addName, addHp);
   monster = m;
 }
 
 /**
 * Call the monster's attack method
 * @return the attack method of monster object
 */
 @Override
 public int attack()
 {
   return monster.attack();
 }
}