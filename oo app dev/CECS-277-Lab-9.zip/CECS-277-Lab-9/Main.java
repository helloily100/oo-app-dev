/**
* Name: Ivy Ly and Ayush Patel
* Date: 10/25/2021
* Description: Reads a txt file, stores and displays the item into a LinkedList in a sorted order.
*/
import java.util.*;
import java.io.*;
class Main 
{
  public static void main(String[] args)
  {
    LinkedList<String> list = new LinkedList<String>();
    ListIterator<String> iter;
    iter = list.listIterator();

    readFile(list);
    moveIter(list);
    printList(list); 
   
  }

  /**
  * @list a LinkedList with string type
  * Read in the file and add each word to the LinkedList.
  */
  public static List<String> readFile(LinkedList<String> list)
  {
  
    //LinkedList<String> list = new LinkedList<String>();
    ListIterator<String> iter;
    try{
      Scanner read = new Scanner(new File("words.txt"));
      while(read.hasNext())
      {
        String word = read.nextLine();
        list.add(word);
        iter = list.listIterator();
        //System.out.println(word);
      }
       //System.out.println(list);

    }catch(FileNotFoundException fnf)
    {
      System.out.println("File wa not found");
    }
   return list;
  }
  

  /**
  * @list a LinkedList with string type
  * Display the contents of the LinkedList.
  */
  public static void printList(LinkedList<String> list)
  {
    ListIterator<String> iter;
    iter = list.listIterator();
    while(iter.hasNext())
    {
      System.out.println(iter.next());
    }
  }

  /**
  * @list a LinkedList with string type
  * Moves the iterator backward and forward from its current position to find the correct location to place the word so the list always stays in sorted order.
  */
  public static void moveIter(LinkedList<String> list)
  {
    ListIterator<String> iter;
    iter = list.listIterator();

    boolean swapped = false;
    do
    {
      swapped = false;
      for( int i = 0; i < list.size() - 1; i++ )
      {
        if( list.get( i ).compareToIgnoreCase(list.get( i + 1 )) > 0 )
        {
            String swap = list.get( i );
            list.set( i, list.get( i + 1 ) );
            list.set( i + 1, swap );
            swapped = true; 
        }

      }
    } while( swapped );

  }
}