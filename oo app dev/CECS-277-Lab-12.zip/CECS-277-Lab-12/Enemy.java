public class Enemy 
{
  /**initialize name, maxHp, and hp*/
  private String name; 
  private int maxHp; 
  private int hp;

  /**
  * @param n intitialize an enemy's name 
  * @param h intitialize maxHp and hp
  * pass in the enemy's name and starting hit points
  */
  public Enemy(String n, int h)
  {
    name = n;
    maxHp = h;
    hp = h;
  }

  /**
  * @param e takes Enemy object
  * A copy constructor for the prototype
  */
  public Enemy(Enemy e)
  {
    if(e != null)
    {
      this.name = e.name;
      this.maxHp = e.maxHp;
      this.hp = e.hp;
    }

  }

  /**
  * @return the name of the enemy object
  */
  public String getName()
  {
    return name;
  }

  /**
  * @return the hp of the enemy object
  */
  public int getHp()
  {
    return hp;
  }

  /**
  * @param h the amount of damage the enemy takes
  * subtract the value from the enemy's hp if the hp values is less than 0, reset to 0
  */
  public void takeDamage(int h)
  {
    hp = hp - h; 
    if(hp < 0)
    {
      hp = 0;
    }

  }

  /**
  * @return a random amount of damage in the range 1- 5
  */
  public int attack()
  {
    return (int)(Math.random() * 5) + 1;
  }

  /**
  * @return the enemy's name and hp
  */
  @Override
  public String toString()
  {
    return name + ": " + hp + "/" + maxHp;

  }

  /**
  * @return a copy of the enemy by calling the copy constructor
  */
  @Override
  public Enemy clone()
  {
    return new Enemy(this);
  }

}