import java.util.*;
import java.io.*;

public class EnemyGenerator
{
  /**initialize ArrayList*/
  private ArrayList<Enemy> enemyList = new ArrayList<Enemy>();

  /**
  * Reads text file of template enemies and store them in the ArrayList
  */
  public EnemyGenerator()
  {
    try
    {
      Scanner read = new Scanner(new File("enemyList.txt"));

      while(read.hasNext())
      {
        String monsters = read.nextLine();
        String [] list = monsters.split(",");
        int num = Integer.parseInt(list[1]);

        Enemy m = new Enemy(list[0], num);
        //enemyList.add(m);
        enemyList.add(m);
          
      }
    }catch(FileNotFoundException fnf)
    {
      System.out.println("File was not found");
    }
  }

  /**
  * @return a random enemy
  * Chooses a random enemy from the ArrayList and creates a copy of it
  */
  public Enemy generateEnemy()
  {
    int rand = (int)(Math.random() * 8);
    Enemy e = enemyList.get(rand);
    return e.clone();
  }

}