/**
* Name: Ivy Ly and Ayush Patel
* Date: 11/15/2021
* Description: Allow user to attack an enemy, and a random enemy will attack the user until the user quits or loses.
*/
class Main {
  public static void main(String[] args){

    // initialize objects and variables
    EnemyGenerator g = new EnemyGenerator();
    Enemy e = g.generateEnemy();
    int userHp = 25; 
    int userMaxHp = 25;
    int counter = 0; 
    int input = 0;

    while((userHp > 0) && (input != 2))
    {
      System.out.println("You have " + userHp + "/" + userMaxHp + " hp.");
      System.out.println("You encounter a " + e.getName());
      System.out.println(e);
      System.out.println("What do you want to do?");
      System.out.println("1. Attack Enemy");
      System.out.println("2. Quit ");
      input = CheckInput.getIntRange(1,2);

      if(input == 1)
      {
        // random damage on enemy
        int damage = (int) (Math.random()* 3) + 1;
        // random damge on user
        int damage2 = (int) (Math.random()* 3) + 1;
        
        System.out.println("You attack " + e.getName() + " for " + damage + " damage" );
        e.takeDamage(damage);

        if(e.getHp() == 0)
        {
          System.out.println("You have slain the " + e.getName());
          e = g.generateEnemy();
          counter++;
        }
        else
        {
          System.out.println(e.getName() + " attacks you for " + damage2 + " damage." );
          userHp -= damage2; 
        }
        System.out.println(e);
        // System.out.println(e.getName());
        // System.out.println("HP:" + e.getHp());
      }

    }
   
    // if the user quits 
    if((userHp > 0) && (e.getHp() == 0))
    {
      System.out.println("Enemies Slain: " + counter);
      System.out.println("Game Over");

    }
    else // if the user loses
    {
      System.out.println("You have died");
      System.out.println("Enemies Slain: " + counter);
      System.out.println("Game Over");
    }
  }

}